//
//  SQTabBarGlobal.m
//
//  Created by Doubles_Z on 16-6-15.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import "SQTabBarGlobal.h"

NSInteger _preIndex = 0;
NSInteger _selectedIndex = 0;

