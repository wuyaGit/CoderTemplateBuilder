//
//  SQCollectionViewSnakeFlowLayout.h
//  Mall
//
//  Created by 双泉 朱 on 17/5/15.
//  Copyright © 2017年 _Zhizi_. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQCollectionViewSnakeFlowLayout : UICollectionViewFlowLayout

@property (nonatomic,assign) NSInteger numPerLine;

@end
