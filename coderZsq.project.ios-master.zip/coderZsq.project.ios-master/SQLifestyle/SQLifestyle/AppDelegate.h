//
//  AppDelegate.h
//  SQLifestyle
//
//  Created by Doubles_Z on 16-5-21.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
