//
//  SQImageGlobal.h
//  SQLifestyle
//
//  Created by Doubles_Z on 16-7-1.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

extern NSString * const kTabbar_lifestyle;
extern NSString * const kTabbar_lifestyle_select;
extern NSString * const kTabbar_discover;
extern NSString * const kTabbar_discover_select;
extern NSString * const kTabbar_profile;
extern NSString * const kTabbar_profile_select;

extern NSString * const kLifestyle_relief;
extern NSString * const kLifestyle_magnifier;
extern NSString * const kLifestyle_hotspots;