//
//  SQImageGlobal.m
//  SQLifestyle
//
//  Created by Doubles_Z on 16-7-1.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import "SQImageGlobal.h"

NSString * const kTabbar_lifestyle        = @"tabbar_lifestyle";
NSString * const kTabbar_lifestyle_select = @"tabbar_lifestyle_select";
NSString * const kTabbar_discover         = @"tabbar_discover";
NSString * const kTabbar_discover_select  = @"tabbar_discover_select";
NSString * const kTabbar_profile          = @"tabbar_profile";
NSString * const kTabbar_profile_select   = @"tabbar_profile_select";

NSString * const kLifestyle_relief    = @"lifestyle_relief";
NSString * const kLifestyle_magnifier = @"lifestyle_magnifier";
NSString * const kLifestyle_hotspots  = @"lifestyle_hotspots";


