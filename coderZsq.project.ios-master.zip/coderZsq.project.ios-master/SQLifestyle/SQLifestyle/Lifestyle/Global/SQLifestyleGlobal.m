//
//  SQLifestyleGlobal.m
//  SQLifestyle
//
//  Created by Doubles_Z on 16-6-24.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import "SQLifestyleGlobal.h"

NSString * const kSQLifestyleBannerKey = @"轮播图";
NSString * const kSQLifestyleSearchKey = @"搜索栏";

NSString * const kSearchBarPlaceholder = @"Searching for something new";