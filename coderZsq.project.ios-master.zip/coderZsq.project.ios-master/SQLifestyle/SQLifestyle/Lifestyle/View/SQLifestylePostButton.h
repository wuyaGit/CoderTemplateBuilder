//
//  SQLifestylePostButton.h
//  SQLifestyle
//
//  Created by Doubles_Z on 16-6-26.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import "SQRemovableButton.h"

@interface SQLifestylePostButton : SQRemovableButton

@end
