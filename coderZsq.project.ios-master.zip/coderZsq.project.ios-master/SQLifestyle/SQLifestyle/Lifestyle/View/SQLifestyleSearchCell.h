//
//  SQLifestyleSearchCell.h
//  SQLifestyle
//
//  Created by Doubles_Z on 16-6-24.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQLifestyleSearchCell : UITableViewCell

+ (instancetype)cellWithTableView:(UITableView *)tableView;

+ (CGFloat)cellHeight;

@end
