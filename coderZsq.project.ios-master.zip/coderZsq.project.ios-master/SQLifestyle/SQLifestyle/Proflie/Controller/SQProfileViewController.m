//
//  SQProfileViewController.m
//  SQLifestyle
//
//  Created by Doubles_Z on 16-5-22.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import "SQProfileViewController.h"

@interface SQProfileViewController ()

@end

@implementation SQProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = GLOBAL_BGC;
}

@end
