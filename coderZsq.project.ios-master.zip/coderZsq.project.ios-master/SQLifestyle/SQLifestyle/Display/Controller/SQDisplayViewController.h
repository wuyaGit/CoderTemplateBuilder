//
//  SQDisplayViewController.h
//  SQLifestyle
//
//  Created by Doubles_Z on 16-6-28.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQDisplayViewController : SQViewController

@end
