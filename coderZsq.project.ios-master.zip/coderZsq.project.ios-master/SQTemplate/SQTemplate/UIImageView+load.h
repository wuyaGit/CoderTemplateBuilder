//
//  UIImageView+load.h
//  SQTemplate
//
//  Created by 双泉 朱 on 17/5/8.
//  Copyright © 2017年 Doubles_Z. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (load)

- (void)loadUrl:(NSString *)imageUrl placeholder:(NSString *)placeholder;

@end
