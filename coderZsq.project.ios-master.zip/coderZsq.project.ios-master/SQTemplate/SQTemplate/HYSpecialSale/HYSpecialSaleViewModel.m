//
//  ViewModelTemplate.m
//  SQTemplate
//
//  Created by 双泉 朱 on 17/5/5.
//  Copyright © 2017年 Doubles_Z. All rights reserved.
//

#import "HYSpecialSaleViewModel.h"
#import "HYSpecialSaleModel.h"

@implementation HYSpecialSaleViewModel

- (void)initializeWithParameter:(NSDictionary *)parameter finishedCallBack:(void(^)())finishCallBack {
    finishCallBack();
}

@end
