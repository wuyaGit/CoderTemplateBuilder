//
//  SubviewTemplate.h
//  SQTemplate
//
//  Created by 双泉 朱 on 17/5/11.
//  Copyright © 2017年 Doubles_Z. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface HYBlockFourSubView : UIView

@property (nonatomic,strong) UIButton * leftTopButton;
@property (nonatomic,strong) UIButton * leftBottomButton;
@property (nonatomic,strong) UIButton * rightTopButton;
@property (nonatomic,strong) UIButton * rightBottomButton;

@end
