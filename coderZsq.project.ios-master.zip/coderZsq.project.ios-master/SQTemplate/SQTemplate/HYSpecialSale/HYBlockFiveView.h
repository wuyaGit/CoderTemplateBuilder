//
//  SubviewTemplate.h
//  SQTemplate
//
//  Created by 双泉 朱 on 17/5/11.
//  Copyright © 2017年 Doubles_Z. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HYBlockFiveSubView;
@class HYBlockTitleView;

@interface HYBlockFiveView : UIView

@property (nonatomic,strong) HYBlockFiveSubView * blockFiveSubView;
@property (nonatomic,strong) HYBlockTitleView * blockTitleView;

@end
