//
//  SubviewTemplate.h
//  SQTemplate
//
//  Created by 双泉 朱 on 17/5/11.
//  Copyright © 2017年 Doubles_Z. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HYBlockOneSubView : UIView

@property (nonatomic,strong) UIButton * leftButton;
@property (nonatomic,strong) UIButton * rightBottomButton;
@property (nonatomic,strong) UIButton * rightTopButton;

@end
