//
//  SubviewTemplate.h
//  SQTemplate
//
//  Created by 双泉 朱 on 17/5/11.
//  Copyright © 2017年 Doubles_Z. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HYBlockTitleView;
@class HYBlockTwoSubView;

@interface HYBlockTwoView : UIView

@property (nonatomic,strong) HYBlockTitleView * blockTitleView;
@property (nonatomic,strong) HYBlockTwoSubView * blockTwoSubView;

@end
