//
//  SQBuilder_iOS.h
//  SQBuilder
//
//  Created by 朱双泉 on 17/08/2017.
//  Copyright © 2017 Castie!. All rights reserved.
//

#import "SQBuilder.h"

@interface SQBuilder_iOS : SQBuilder

@end
