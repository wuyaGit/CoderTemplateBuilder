//
//  SQBuilder_Android.m
//  SQBuilder
//
//  Created by 朱双泉 on 17/08/2017.
//  Copyright © 2017 Castie!. All rights reserved.
//

#import "SQBuilder_Android.h"

@implementation SQBuilder_Android

- (void)build {
    NSLog(@"Android");
}

@end
