//
//  SQBuilder_Android.h
//  SQBuilder
//
//  Created by 朱双泉 on 17/08/2017.
//  Copyright © 2017 Castie!. All rights reserved.
//

#import "SQBuilder.h"

@interface SQBuilder_Android : SQBuilder

@end
