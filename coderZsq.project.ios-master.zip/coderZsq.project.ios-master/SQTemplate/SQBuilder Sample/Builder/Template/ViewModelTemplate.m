//
//  ViewModelTemplate.m
//  SQTemplate
//
//  Created by 双泉 朱 on 17/5/5.
//  Copyright © 2017年 Doubles_Z. All rights reserved.
//

#import "<#Unit#>ViewModel.h"
#import "<#Unit#>Model.h"

@implementation <#Unit#>ViewModel

- (void)initializeWithParameter:(NSDictionary *)parameter finishedCallBack:(void(^)())finishCallBack {

}
<#ViewModelImplementation#>

@end
